#include "shade.h"

Shade::Shade(): Player("Shade", 125, 25, 25) {}


