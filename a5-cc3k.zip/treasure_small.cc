#include "treasure_small.h"

Treasure_Small::Treasure_Small(): 
  Treasure(TREASURE_SMALL_VALUE, "small treasure") {}
