#include "item.h"
using namespace std;

Item::Item(char sym, string name): Entity(sym, name) {}
