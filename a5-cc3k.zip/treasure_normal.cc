#include "treasure_normal.h"

#include "treasure_normal.h"

Treasure_Normal::Treasure_Normal(): 
  Treasure(TREASURE_NORMAL_VALUE, "normal treasure") {}
