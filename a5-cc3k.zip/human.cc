#include "human.h"


Human::Human(): 
   Enemy{'H', "Human", 140, 20, 20} {}
