#ifndef _SHADE_H_
#define _SHAdE_H_

#include <memory>
#include "player.h"

class Shade: public Player {
 public:
  Shade();
};    

#endif
