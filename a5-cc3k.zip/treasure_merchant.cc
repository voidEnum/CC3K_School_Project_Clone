#include "treasure_merchant.h"

Treasure_Merchant::Treasure_Merchant(): 
  Treasure(TREASURE_MERCHANT_VALUE, "merchant hoard"){}


